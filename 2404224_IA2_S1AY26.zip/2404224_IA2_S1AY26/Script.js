// Get references to the registration form and input fields for first name, last name, and email
const form = document.getElementById("rform");
const fnameField = document.getElementById("fname");
const lnameField = document.getElementById("lname");
const emailField = document.getElementById("email");

// Add a submit event listener to validate form inputs when user submits the registration form
form.addEventListener("submit", function (e) {
  let errors = [];

  // Check if first name is empty after trimming whitespace
  if (fnameField.value.trim() === "") {
    errors.push("First name is required.");
  }

  // Check if last name is empty after trimming whitespace
  if (lnameField.value.trim() === "") {
    errors.push("Last name is required.");
  }

  // Validate email contains an '@' character
  if (!emailField.value.includes("@")) {
    errors.push("Enter a valid email.");
  }

  // If there are errors, prevent form submission and display alerts with issues
  if (errors.length > 0) {
    e.preventDefault(); 
    alert(errors.join("\n"));
  } else {
    // On successful validation, prevent default to show alert then redirect to Products page
    e.preventDefault(); 
    alert("Registration successful! Press ok to continue to Products page.");
    window.location.href = "Products.html";
  }
});

// Add input event listener on email field to apply or remove error style dynamically
emailField.addEventListener("input", function () {
  if (!isValidEmail(emailField.value)) {
    emailField.classList.add("error-border"); // add red border for invalid email
  } else {
    emailField.classList.remove("error-border"); // remove error border when valid
  }
});

// Function to validate email format using regex pattern
function isValidEmail(email) {
  // Matches string with non-whitespace chars, an '@', more non-whitespace chars, a '.', then non-whitespace chars
  return /\S+@\S+\.\S+/.test(email);
}

